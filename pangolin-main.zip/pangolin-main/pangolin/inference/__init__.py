from pangolin.inference import numpyro
from .numpyro import sample, E, std, var